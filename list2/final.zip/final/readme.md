# SME0130 Complex Networks
# Project 2: Centrality, degree-degree correlation and community structure in networks
## Professor Dr. Francisco Aparecido Rodrigues

## Students
Flavio Vinicius Vieira Santana	NUSP 9866552
Mateus Castilho Leite			NUSP 9771550
