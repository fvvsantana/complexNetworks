# SME0130 Complex Networks
# Exercises I
## Professor Dr. Francisco Aparecido Rodrigues

## Students
Flavio Vinicius Vieira Santana	NUSP 9866552
Mateus Castilho Leite			NUSP 9771550

